# Descargo Lemon Caso 119 (4392185).pdf

> Transcribed from PDF using agent vision
> Pages: 4

---

## Page 1

[IMAGE]
Type: logo
Summary: Lemon logo in the top-right corner — a black rounded square containing a green lemon silhouette with the word "LEMON" beneath it.
[/IMAGE]

**DESCARGO LEMON**

<u>CASO</u>: 119

PARTE: <u>DESCARGO LEMON</u>

El usuario manifiesta haber realizado un retiro de 28,37 USDT enviando los fondos a una cuenta correcta pero utilizando por error la red BNB Chain (BEP20) en lugar de la red Ethereum (ERC20.

1. Operatoria realizada

Del análisis técnico realizado por el equipo de soporte de Lemon, se confirma que:

La transacción se ejecutó correctamente desde la cuenta del usuario, a través de la red BEP20, y figura como "completada" en blockchain.

El hash de la transacción (0x6ef7a4b8f3bb4771ff880ca2248d4a4edb) demuestra la efectiva salida de los fondos desde Lemon hacia la dirección indicada por el usuario.

No hubo fallas del sistema, errores técnicos ni cancelaciones, motivo por el cual Lemon no conserva ni controla los fondos una vez que la transacción fue confirmada por la red.

2. Advertencia y la responsabilidad del usuario

Lemon informa de manera expresa y visible que las redes de envío y recepción deben coincidir, y que el uso de redes incompatibles puede implicar la pérdida total de los fondos. Estas advertencias están disponibles tanto:

- En la interfaz de retiro, previo a la confirmación de la transacción;
- Como en los Términos y Condiciones aceptados por el usuario al operar con la aplicación.

Cabe destacar que, al momento de realizar un retiro, la plataforma de Lemon informa de forma clara que la red de origen y destino deben coincidir, advirtiendo que, de no cumplirse esta condición, los fondos podrían no acreditarse y como es este caso en particular, como mencionamos anteriormente resultar irrecuperables.

1

## Page 2

[IMAGE]
Type: logo
Summary: Lemon logo in the top-right corner — a black rounded square containing a green lemon silhouette with the word "LEMON" beneath it.
[/IMAGE]

[IMAGE]
Type: screenshot
Summary: Screenshot of the Lemon mobile app's "Enviar BTC" screen showing the destination-address input flow, with a note that addresses must belong to Bnb Chain (BEP20), Bitcoin, Lightning Network or Rootstock.
Text:
12:02
< Enviar BTC
Ingresá una dirección de destino
Podés enviar a direcciones de billeteras que pertenezcan a la red Bnb Chain (BEP20), Bitcoin, Lightning Network o Rootstock.
Dirección de destino    Pegar
Mi agenda
Todavía no tenés ninguna dirección de BTC en tu agenda
Agregar dirección
[/IMAGE]

En este caso en particular, el usuario manifiesta que seleccionó la red Bnb Chain (BEP20) de manera manual, cuando el destinatario esperaba recibir a través de la red Ethereum (ERC-20). Esta acción, ejecutada directamente por el usuario, configura un error operativo por parte del mismo al seleccionar una red incompatible con la plataforma receptora, y los fondos se enviaron pero no fueron recibidos por el receptor ya que se envió por una red que el receptor no tiene configurada.

[IMAGE]
Type: screenshot
Summary: Screenshot of a Lemon support chat window with user "Alexander Nahuel Flores Cossio", showing a Re-open button at top right and a back-and-forth exchange between the Lemon agent (light blue right-aligned bubbles) and the user (grey left-aligned bubbles), followed by an embedded transaction-confirmation card for 28,37 USDT.
Text:
Alexander Nahuel Flores Cossio    [star] [...] [box] [phone] [lock] Re-open

[Agent]: ¡Gracias por la info! Revisé en el sistema y veo que ese envio se confirmó correctamente desde Lemon.
Si la transacción no aparece acreditada en la wallet de destino, te recomiendo que te pongas en contacto con la entidad receptora con estos datos:    3d
[Agent]: moneda: USDT
red: BEP20
dirección_destino: 0x05cA9947B76Ffa9373c0031D6246BdE2343736C8
hash: 0x6ef7a4b8f3bb47712c5048aed1323506a2c1ef8e50db00ff880ca2248d4a4edb    3d
                                            ¡Gracias! Eso era todo.    Aún no llegó    Otro inconveniente

[User - Otro inconveniente]
A   3d • Quick reply

[Agent]: Antes de pasarte con alguien del equipo, ¿me contarías más detalles sobre que fue lo que pasó?    3d

[User]: La cuenta es la correcta pero la red es una que use anteriormente y no la que corresponde por eso no llego nunca el retiro , me gustaría saber si es posible por esta vez una solución favorable para ambas partes
A   3d

[Agent]: ¡Gracias! Si querés sumar más info, hacelo mientras esperás la respuesta del equipo.    3d

[User]: Cuanto debo esperar?
[User]: Preciso el dinero
A   3d

[Embedded transaction card]
3:50    [signal] LTE [30]
[T icon]  28,37 USDT
          Retiro de USDT
          22 Octubre 2025 - 09:34 hs.
[check]  Completo
          Tu envío ya fue realizado.

Reply ∨
Use /## for shortcuts
[lightning]                                       Send ∨
[/IMAGE]

Confirmación que seleccionó una red incorrecta **ref.captura de chat de soporte**

2

## Page 3

[IMAGE]
Type: logo
Summary: Lemon logo in the top-right corner — a black rounded square containing a green lemon silhouette with the word "LEMON" beneath it.
[/IMAGE]

De acuerdo con los Términos y Condiciones aceptados por el usuario al operar en Lemon, específicamente la cláusula 6, se establece que:

> "…La Empresa, no se responsabiliza por el envío a través de redes incorrectas o de Activos Digitales que no sean soportados y el Usuario reconoce que dicha operatoria podrá ocasionar que los Activos Digitales no lleguen a destino…"

Esta disposición responde a los principios técnicos de operación de la economía blockchain, en el que las transferencias una vez ejecutadas y confirmadas por la red no pueden ser revertidas ni anuladas, tal como figura en nuestros Términos y Condiciones específicamente en la cláusula 3.

> 3.2. Los Usuarios utilizarán los Servicios en la Plataforma, emitiendo las instrucciones para compra, venta, canje, permuta y la custodia de Activos Digitales a través de la misma (la "Instrucción").
>
> 3.3. Al emitir una Instrucción, el Usuario acepta que una vez ejecutada la misma a través de la Plataforma, dicha transacción **es irreversible y no se puede cancelar.**

El usuario reconoce expresamente en su presentación que seleccionó una red incorrecta y que el error fue propio de la operatoria manual.

Asimismo, solicita que Lemon asuma el costo total o parcial de la pérdida, basándose en principios de protección al consumidor y buena fe.

Sin embargo:

- La pérdida no se origina por una omisión, error o mal funcionamiento del sistema de Lemon, sino por la selección voluntaria de una red distinta por parte del usuario, acción que no puede ser revertida ni corregida una vez emitida en blockchain.
- Lemon no tiene acceso ni control sobre los fondos enviados fuera de su plataforma, por lo cual no es jurídicamente ni técnicamente posible realizar un reintegro.
- La función de "doble confirmación" mencionada por el usuario no existe su responsabilidad operativa, ya que el sistema ya exige confirmar explícitamente la red seleccionada antes del envío.

En los registros internos de Lemon consta que ambas transferencias se ejecutaron correctamente, con confirmación de la red de Bnb Chain (BEP20) y sin error de sistema. La red de destino fue ingresada por el propio usuario erróneamente, sin poder modificar dicha instrucción, es por ello que nosotros no tenemos potestad de esos fondos, ya que no se encuentran en nuestra Plataforma, una vez que se

3

## Page 4

[IMAGE]
Type: logo
Summary: Lemon logo in the top-right corner — a black rounded square containing a green lemon silhouette with the word "LEMON" beneath it.
[/IMAGE]

ejecuta la instrucción del usuario.

Lemon actuó en todo momento conforme a sus obligaciones legales y contractuales, brindando la información correspondiente al momento de la operación y ejecutando el retiro tal como fue solicitado con la instrucción realizada por el usuario.

La situación descripta no configura una falla del sistema ni un incumplimiento por parte de Lemon, sino una selección incorrecta de la red por parte del usuario, lo cual se encuentra expresamente advertido y previsto en nuestros Términos y condiciones.

Lemon cumple con su deber de información, transparencia y seguridad poniendo como deber principal la buena experiencia del usuario, advirtiendo de forma clara los riesgos asociados a la selección de red, sin que existiera ocultamiento, omisión o error inducido.

Por lo expuesto, mantenemos nuestra posición y solicitamos el rechazo del reclamo.

4
