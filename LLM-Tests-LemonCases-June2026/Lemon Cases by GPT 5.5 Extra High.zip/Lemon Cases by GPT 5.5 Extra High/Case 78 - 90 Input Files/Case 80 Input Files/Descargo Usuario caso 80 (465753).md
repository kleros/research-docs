# Descargo Usuario caso 80 (465753).pdf

> Transcribed from PDF using agent vision
> Generated: 2026-05-19 12:41:00
> Pages: 3

---

## Page 1

[IMAGE]
Type: logo
Summary: Purple KLEROS banner with the Kleros geometric logo and the word "KLEROS".
[/IMAGE]

### Motivo del reclamo

Problemas Crypto

### ¿Por qué motivos crees que debes ganar el caso?:

El día de ayer, realicé una transferencia de **31.38 tokens de GRASS** a mi cuenta de Lemon, utilizando la red Solana y asumiendo las comisiones correspondientes. Posteriormente, fui informado de que **no se acreditaría el monto** en mi cuenta. Según las **Preguntas Frecuentes** de Lemon, es posible recuperar tokens no listados, aplicando una comisión del 10% por la recuperación

“Lemon Help”. Sin embargo, en este caso, no se me brindó una explicación adicional ni se me ofreció la opción de recuperar mis fondos.

De acuerdo con el **Principio de Transparencia**, Lemon tiene la obligación de proporcionar información clara y precisa sobre las operaciones y procedimientos relacionados con depósitos de criptomonedas no listadas. Además, el **Principio de Protección al Consumidor** establece que se deben salvaguardar los intereses económicos de los usuarios, ofreciendo soluciones justas en situaciones como esta.

Por estos motivos, solicito que se me brinde una **explicación detallada** sobre la imposibilidad de recuperar mis fondos y que se me ofrezca una **solución justa**, ya sea mediante la acreditación de los tokens en mi cuenta o la devolución de los mismos, aplicando la comisión correspondiente según lo establecido en las políticas de Lemon.

Agradezco de antemano su atención y espero una resolución favorable a mi reclamo.

### Pruebas:

[Watermark: faint Kleros geometric logo behind the body text.]

## Page 2

[IMAGE]
Type: logo
Summary: Purple KLEROS banner with the Kleros geometric logo and the word "KLEROS".
[/IMAGE]

[IMAGE]
Type: screenshot
Summary: Mobile Solscan transaction action view showing a GRASS transfer and associated SOL deposit.
Text:
17:04

Transaction Actions

Tx Maps

Legacy Mode

View Token Account

Interact with instruction Create on
Associated Token Account Program

Create HwPo8D...WtHEu7

with deposit of
0.00203928 ($0.3643) SOL from
4sWVeX...RqgDsG

Interact with instruction
TransferChecked on Token Program

Transfer from 4sWVeX...RqgDsG
to 5dkzj7...gWJntW for
31.38 ($31.85) GRASS

Sponsored

solscan.io
[/IMAGE]

## Page 3

[IMAGE]
Type: logo
Summary: Purple KLEROS banner with the Kleros geometric logo and the word "KLEROS".
[/IMAGE]

[IMAGE]
Type: screenshot
Summary: Composite of a Lemon support chat and a Lemon help article about unsupported networks and unlisted coins.
Text:
17:05

Lauty
Activo en los últimos 15m

fondos reclamados.

Entiendo que esto sea una mala experiencia, y quiero ayudarte a evitar que vuelva a pasar en un futuro.

Para eso, te comparto 2 artículos de nuestro centro de ayuda en los cuales vas a poder ver como operar con Lemon y los riesgos asociados al uso de crypto:

👉 ¿Cómo deposito crypto en Lemon? Y ¿Qué red selecciono

Por último, en el siguiente link al explorador de bloques, vas a poder verificar los detalles de la transacción.

Quedo a tu disposición para lo que necesites.

no, entendi, la transacción fue devuelta?

Escribe un mensaje...
Enviar

17:05

Cada red cobra una comisión o "gas".
Podés leer más en nuestra WIKI.

Envié una moneda que no está listada y/o por medio de una red no disponible. ¿Qué hago?

Es probable que recibieras un correo y notificación. Tene en cuenta la información que allí se detalla. Si no recibiste un correo o aviso en la app luego del envío, contactá a soporte por el chat de la app con el hash y revisamos si puede recuperarse.

Si podemos recuperarlos y fueron enviados por ERC20, el monto mínimo recuperable es de 40 USD. Para otras redes, debe ser al menos 1 USD. En todos los casos, se aplicarán costos de red y una comisión de recuperación del 10%, según lo establecido en los artículos 13.6 y 13.7 de nuestros Términos y Condiciones. Esto significa que recibirás menos fondos de los que depositaste en tu cuenta.

¡Importante!

Las redes que informamos en este artículo son solamente para ingresos. Para los retiros crypto podés verlas haciendo click acá.

Si tenés alguna duda, escribinos a soporte@lemon.me o contactate por la app desde [?]
[/IMAGE]
