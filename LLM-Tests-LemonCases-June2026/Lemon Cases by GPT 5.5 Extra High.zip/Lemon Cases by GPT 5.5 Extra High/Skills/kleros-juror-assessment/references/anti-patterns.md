# Anti-Patterns — Common Juror Mistakes

These are the most common ways a juror produces an incoherent vote (one that disagrees with the final majority and gets slashed). An agent acting as a juror must actively avoid each of them.

---

## 1. Voting on Personal Preference Rather Than Policy

"I don't like this token." "This submission looks low-effort." "The plaintiff seems greedy."

None of these are valid grounds. The vote must be derived from the policy applied to the evidence, not from your taste. If the policy criteria are met, vote accept — even if the project disappoints you. If the criteria are not met, vote reject — even if the project is exciting.

---

## 2. Voting on What You Wish the Rule Were

"The policy should require X." Maybe it should — but it doesn't, and reform happens through governance, not through incoherent voting. The policy is fixed for this case. Apply it.

---

## 3. Failing to Read the Primary Documents

The single most common cause of incoherent votes. Always read, in this order:

1. The question and ruling options descriptions in the dispute template.
2. The primary document (case-specific policy).
3. The subcourt policy.
4. The General Court policy.

Skipping any of these means relying on assumptions that may be wrong.

---

## 4. Anchoring on the First Piece of Evidence

The party who submits first frames the case. If you read their evidence first and form an impression, every subsequent piece of evidence gets evaluated against that impression. Counter this by reading evidence in chronological order of events, and by deliberately looking for evidence that *disconfirms* your initial impression.

---

## 5. Using "Refuse to Arbitrate" as an Abstention

This is **the single most expensive mistake an agent can make**. RtA is not "I'm not sure." It is a substantive vote that wins the case if it gets the majority. Voting RtA when the case has a clear answer under the policy is an incoherent vote.

Vote RtA **only** when:
- Jurisdiction failure (wrong subcourt).
- Morality failure (General Court clause).
- Validity failure (malformed/ambiguous question, impossible to answer from materials).
- Procedural failure flagged by the policy (e.g. unflagged large translation).
- The RtA option is the substantively correct answer (Reality.eth "Invalid" cases).

Do **not** vote RtA because the case is hard, because the evidence conflicts, because you feel uncomfortable, or because you suspect the appeal will fix it.

---

## 6. Voting with the Perceived Whale or Loudest Party

"This party has more on-chain wealth, so they'll fund the appeal and win anyway." This is wrong on two levels:

- It's not how Kleros works. The appeal mechanism is designed to make truthful votes coherent over multiple rounds.
- Even when it works out for one case, it makes the juror unreliable across cases — and incoherence accumulates.

Vote your honest read of the policy.

---

## 7. Trusting Other Jurors' Justifications as Social Proof

Other jurors' justifications are visible. Read them for *arguments*, not as social proof. Their interests are not necessarily aligned with yours, and they may be mistaken. Be especially wary of justifications that are short, generic, or repeated across cases — these are often low-effort or automated and shouldn't influence you.

---

## 8. Speculating About Appeals

"I'll vote X because if I'm wrong the appeal will fix it." No. The appeal might not happen — un-crowdfunded appeals lose by default even when the answer is wrong. And even if the appeal does happen, coherence is measured against the *final* ruling, so your round-1 vote still needs to match the truthful answer.

Vote your honest read of the policy, every round.

---

## 9. Missing the Deadline

Failing to vote (or reveal, in commit-reveal courts) before the deadline is automatically slashed and produces no fee. An agent acting as a juror must always submit before the deadline closes, even if confidence is lower than ideal.

---

## 10. Voting in a Court Without the Required Skills

The Solidity court is not the place for a juror who can't read Solidity. The English-Spanish translation court is not the place for a juror without near-native fluency in both. An agent should declare which competence it is invoking on a given case, and *recuse* (in human terms) by refusing the assignment if it lacks competence.

For an AI agent specifically: if the case requires domain knowledge the agent doesn't have (e.g. interpreting a complex MEV exploit), the agent should explicitly flag the gap rather than guess.

---

## 11. Always-Reject or Always-Accept Strategies

On historical data, certain Kleros lists rejected ~70% of submissions. A juror who always votes "reject" could attain a better-than-random success rate without analysis. This is an attack on the system, and the protocol's incentive design is intended to discourage it.

An agent must analyse each case on its own merits. Don't pattern-match to "this type of case usually goes X" — pattern-match to "what does this policy applied to this evidence say."

---

## 12. Ignoring the General Court Morality Clause

Even a substantively well-argued case can require RtA if a party has engaged in immoral activities as defined: murder, slavery, rape, violence, theft, perjury. Perjury includes submitting fabricated evidence.

Always run this check before voting in favour of either party. It's quick and it catches edge cases where the substantive analysis would otherwise produce the wrong vote.

---

## 13. Confusing Materiality with Vividness

A photo of a crying victim is vivid. It is not necessarily material. A boring spreadsheet of payment dates may be the most material piece of evidence in the case. The policy criteria define materiality; nothing else does.

---

## 14. Treating the Dispute as Adversarial Litigation

Kleros is closer to crowdsourced administrative adjudication than to advocacy litigation. The juror does not have a "side". There is no "winner" in the sense of "the party I rooted for". There is only "the option that the policy applied to the evidence requires", which may be one party, the other, or RtA.

If you find yourself building a narrative about "the good party" and "the bad party", reset. The framing itself is the bias.

---

## 15. Writing a Vague Justification

"Vote: Yes. Justification: Based on the evidence, I think Yes is correct."

This is incoherent in a different sense — it doesn't help future jurors, doesn't help the parties, and signals low effort. A good justification:

- Cites the specific policy clause being applied.
- Names the material evidence relied on.
- Explains the application in one or two sentences.
- States the conclusion in the language of the ruling options.

A justification this specific takes 2–3 paragraphs and is easy to write once the seven-step framework has been followed.

---

## 16. Skipping the Bias Audit

Even competent jurors anchor, follow celebrity, or get swayed by polished writing. The bias audit step (Step 6 in the main workflow) catches these before they become a vote. Don't skip it because the case "feels clear" — those are the cases where bias is most likely operating undetected.
